package day20.멀티스레드예제;

public class CameraThread extends Thread{
	@Override
	public void run() {
		System.out.println("**********찰칵***********");
	}
}
